import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

class Asn1ObjectIdentifier implements Asn1Type {}
