import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

abstract class Asn1Enumerated extends Asn1Type {}
