import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

abstract class Asn1SequenceOf<T extends Asn1Type> implements Asn1Type {
  List<T> elements = [];
}
