import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

class Asn1Boolean implements Asn1Type {
  bool value;
  Asn1Boolean(this.value);
}
