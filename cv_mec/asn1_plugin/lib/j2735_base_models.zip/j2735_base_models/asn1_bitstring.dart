import 'package:asn1_plugin/generated_bindings.dart';
import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

abstract class Asn1BitString extends Asn1Type {
  BIT_STRING_s value;
  Asn1BitString(this.value);
}
