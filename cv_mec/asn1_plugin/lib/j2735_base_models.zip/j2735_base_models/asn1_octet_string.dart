import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';
import 'package:asn1_plugin/generated_bindings.dart';

class Asn1OctetString implements Asn1Type {
  late OCTET_STRING_t value;
  Asn1OctetString(this.value);
}
