import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

abstract class Asn1CharacterString extends Asn1Type {
  String value;
  Asn1CharacterString(this.value);
}
