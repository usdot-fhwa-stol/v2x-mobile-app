import 'package:asn1_plugin/j2735_base_models/asn1_type.dart';

class Asn1Integer implements Asn1Type {
  int value;
  Asn1Integer(this.value);
}
