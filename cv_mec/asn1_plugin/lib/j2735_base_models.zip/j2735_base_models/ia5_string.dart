import 'package:asn1_plugin/j2735_base_models/asn1_character_string.dart';
import 'package:asn1_plugin/generated_bindings.dart' as C;

class IA5String extends Asn1CharacterString {
  IA5String(C.OCTET_STRING value) : super(value.buf.toString()) {}
}
